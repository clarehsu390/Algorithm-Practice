require_relative 'heap'

def k_largest_elements(array, k)
    store = BinaryMinHeap.new()
    array[k...array.length].each do |el|
        store.push(el)
    end
    array[k...array.length].each do |el|
        if el > store.peek
            store.extract
        end
    end
    store
end
